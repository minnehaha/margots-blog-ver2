<div id="footer">
	Copyright &copy; <?php echo date("Y"); ?> <a href="<?php echo home_url(); ?>" title="<?php bloginfo("name"); ?>" rel="home"><?php bloginfo("name"); ?></a>. All rights Reserved.<br />
	Powered by <a href="http://kapasoft.com" title="KapaSoft Web Solutions Website" target="_blank">KapaSoft</a>.
</div><!-- END #footer -->

<?php wp_footer(); ?>
</body>
</html>