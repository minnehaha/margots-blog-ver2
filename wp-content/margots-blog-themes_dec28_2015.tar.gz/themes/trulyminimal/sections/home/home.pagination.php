<?php if ( have_posts() ) : ?>

	<?php themef_pagination(); ?>

<?php endif; ?>