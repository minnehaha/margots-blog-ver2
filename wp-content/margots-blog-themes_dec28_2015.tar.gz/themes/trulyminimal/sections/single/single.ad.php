<?php if( frameworkads_display_zone('after-post-zone') ) : ?>
<div class="section-advertisement">
	<?php echo frameworkads_display_zone('after-post-zone'); ?>
</div>
<?php endif; ?>