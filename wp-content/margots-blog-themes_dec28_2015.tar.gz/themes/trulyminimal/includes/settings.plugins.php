<?php
/*  Include About The Author Plugin  */
require_once ($incPath . '/plugins/plugin.about-author.php');
?>