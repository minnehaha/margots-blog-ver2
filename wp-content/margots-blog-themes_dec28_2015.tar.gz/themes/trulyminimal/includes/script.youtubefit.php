<?php
if ( framework_get_option('script_youtubefit_active') )
        if ( !is_admin() && !is_feed() )
            themef_enqueue_script('jquery-youtubefit', 'jquery.youtubefit.min.js');
?>