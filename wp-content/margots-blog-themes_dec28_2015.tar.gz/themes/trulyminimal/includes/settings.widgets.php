<?php
/*  Include About Us Widget  */
require_once ($incPath . '/widgets/widget.about-us.php');

/*  Include Latest Comments Widget  */
require_once ($incPath . '/widgets/widget.latest-comments.php');

/*  Include Most Popular Posts Widget  */
require_once ($incPath . '/widgets/widget.most-popular-posts.php');

/*  Include Latest Posts Widget  */
require_once ($incPath . '/widgets/widget.latest-posts.php');

/*  Include Random Posts Widget  */
require_once ($incPath . '/widgets/widget.random-posts.php');

/*  Include Tags Widget  */
require_once ($incPath . '/widgets/widget.tags.php');

/*  Include Search Widget  */
require_once ($incPath . '/widgets/widget.search.php');
?>