<?php
/*-------------------------------------------------------------
*   Include settings files
*------------------------------------------------------------*/
require_once ($incPath . '/framework/framework.init.php');

require_once ($incPath . '/settings.menus.php');

require_once ($incPath . '/settings.pagination.php');

require_once ($incPath . '/settings.scripts.php');

require_once ($incPath . '/settings.sidebars.php');

require_once ($incPath . '/settings.thumbnails.php');

require_once ($incPath . '/settings.plugins.php');

require_once ($incPath . '/settings.widgets.php');

require_once ($incPath . '/settings.shortcodes.php');


/*-------------------------------------------------------------
*   Include Scripts
*------------------------------------------------------------*/
require_once ($incPath . '/script.fancybox.php');

require_once ($incPath . '/script.imagefit.php');

require_once ($incPath . '/script.youtubefit.php');

require_once ($incPath . '/script.focusform.php');


/*-------------------------------------------------------------
*   Check Minimum Requirements
*------------------------------------------------------------*/
function themef_check_minimum_requirements() {
	//Check WP Version
	if (version_compare( get_bloginfo('version') , '3.0', '<')) {
		wp_die( 'You must have at least version 3.0 for WordPress.<br />Your WordPress version is ' .get_bloginfo('version') );
	}

	//Check PHP Version
	if (version_compare(PHP_VERSION, '5.0.0', '<')) {
		wp_die( 'You must have at least version 5.0.0 for PHP.<br />Your PHP version is ' . PHP_VERSION );
	}
}
add_action( 'get_header', 'themef_check_minimum_requirements');


/*-------------------------------------------------------------
*   Setup languages
*------------------------------------------------------------*/
load_theme_textdomain('trulyminimal' , get_template_directory() . '/languages');


/*-------------------------------------------------------------
*   Set content width
*------------------------------------------------------------*/
if ( ! isset( $content_width ) ) $content_width = 955;


/*-------------------------------------------------------------
*   Add automatic feed links
*------------------------------------------------------------*/
add_theme_support( 'automatic-feed-links' );


/*-------------------------------------------------------------
*   Function to limit the characters from a string
*------------------------------------------------------------*/
function themef_limit_characters($content, $limit = 50, $p = false) {
	$thiscontent = strip_tags( $content );
	$content_length = strlen($thiscontent);
	
	if($content_length <= $limit) {
		$thisexcerpt = $thiscontent;
	} else {
		$thisexcerpt = $thiscontent . ' ';
		$thisexcerpt = substr($thisexcerpt, 0, $limit);
		$thisexcerpt = substr($thisexcerpt, 0, strrpos($thisexcerpt, ' '));
		$thisexcerpt .= ' ... ';
	}

	if( !$p )
		return $thisexcerpt;
	else
		return '<p>' . $thisexcerpt . '</p>';
}


/*-------------------------------------------------------------
*   Set wp_title
*------------------------------------------------------------*/
function themef_wp_title( $title ) {
	global $paged;

	//Add page title
	$site_name = $title;

	//Add blogname
	$site_name .= get_bloginfo('name');

	//Add page number
	if( isset($paged) && ($paged >= 2) )
		$site_name .= ' | ' . sprintf( __( 'Page %s', 'trulyminimal' ), $paged );

	return $site_name;
}
add_filter( 'wp_title', 'themef_wp_title' );


/*-------------------------------------------------------------
*   The Excerpt settings
*------------------------------------------------------------*/
function themef_new_excerpt_length($length) {
	return 75;
}

function themef_new_excerpt_more($more) {
       global $post;
	return ' ...';
}

add_filter('excerpt_more', 'themef_new_excerpt_more');
add_filter('excerpt_length', 'themef_new_excerpt_length');


/*-------------------------------------------------------------
*   A bug in wordpress
*------------------------------------------------------------*/
function themef_valid_search_form ($form) {
	return str_replace('role="search" ', '', $form);
}
add_filter('get_search_form', 'themef_valid_search_form');


/*-------------------------------------------------------------
*   A bug in wordpress
*------------------------------------------------------------*/
function themef_img_caption( $empty_string, $attributes, $content ) {
	extract(shortcode_atts(array(
		'id' => '',
		'align' => 'alignnone',
		'width' => '',
		'caption' => ''
	), $attributes));

	if ( empty($caption) )
		return $content;
	
	if ( $id ) $id = 'id="' . esc_attr($id) . '" ';
	return '<div ' . $id . 'style="width:' . $width . 'px;" class="wp-caption ' . esc_attr($align) . '">' . do_shortcode( $content ) . '<span class="wp-caption-text">' . $caption . '</span></div>';
}
add_filter( 'img_caption_shortcode', 'themef_img_caption', 10, 3 );


/*-------------------------------------------------------------
*   Change Protected Post Form
*------------------------------------------------------------*/
function themef_custom_password_form() {
	global $post;
	$label = 'pwbox-'.( empty( $post->ID ) ? rand() : $post->ID );
	$o = '<form class="protected-post-form" action="' . get_option('siteurl') . '/wp-pass.php" method="post">
		<p>' . __( "This post is password protected. To view it please enter your password below:", 'trulyminimal' ) . '</p>
		<label for="' . $label . '">' . __( "Password:", 'trulyminimal' ) . ' </label>
		<input name="post_password" id="' . $label . '" type="password" size="20" />
		<input type="submit" name="Submit" value="' . esc_attr__( "&nbsp;&nbsp;submit &rarr;", 'trulyminimal' ) . '" />
	</form>
	';
	return $o;
}
add_filter( 'the_password_form', 'themef_custom_password_form' );
?>