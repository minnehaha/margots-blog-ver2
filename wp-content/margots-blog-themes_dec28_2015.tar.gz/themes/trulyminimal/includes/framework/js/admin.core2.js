/* -----------------------------
*  Menu Tabs
* --------------------------- */
jQuery(function() {
	jQuery( ".fpMetaboxes" ).tabs({
		fx: { opacity: "toggle", duration: "fast" }, selected: 0
	});
});