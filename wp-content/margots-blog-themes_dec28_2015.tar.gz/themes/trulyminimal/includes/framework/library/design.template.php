<?php
/*
* Include design
*/
require_once ('design.head.php');
require_once ('design.navigation.php');
require_once ('design.maincontent.php');
require_once ('design.footer.php');
?>