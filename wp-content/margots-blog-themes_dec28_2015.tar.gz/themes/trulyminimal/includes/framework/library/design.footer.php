
			<br style="clear: both" />
		</div>

		<div id="fpFooter">
			<div id="fpLeft">
				<a href="http://www.flarethemes.com" target="_blank">Flare Themes WebSite &raquo;</a>
			</div>

			<input class="fpSave button-primary" name="submit" value="Save Options" type="submit" />
		</div>
	</div>
	</form>

	<form method="post">
	<input type="hidden" name="action" value="reset" />

	<div id="fpFOptions">
		<h2>Restore settings</h2>
		<p>
			<input class="button-secondary reset-options" type="submit" id="fpRestore" name="reset" value="Restore Settings To Default" />
			Use this button to restore settings to their defaults. (Note: This action is irreversible.)
		</p>
	</div>
	</form>