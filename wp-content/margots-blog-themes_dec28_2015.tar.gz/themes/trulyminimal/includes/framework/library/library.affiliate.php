
					<div class="wAffiliate">
						<h2>Sweet! You've installed our <?php echo THEMENAME; ?> theme!</h2>
						<h3>Join our affiliate program today and earn a whooping 30% from each sale</h3>
						
						<a href="http://www.flarethemes.com/affiliates/" title="FlareThemes Affiliate Program" class="affiliate-link"></a>
						
						<p>When you join our affiliate program, you will be supplied with a range of banners and textual links that you place within your site. When a user clicks on one of your links, they will be brought to our website and their activity will be tracked by our affiliate software. You will earn a 30% commission for each sale.</p>
						
						<div class="clear"></div>
					</div>