<?php get_header(); ?>

<div id="main">
	<?php get_sidebar(); ?>
	
	<div id="content">
		<?php get_template_part( 'loop', 'attachment' ); ?>
	</div><!-- END #content -->

	<div class="clear"></div>
</div><!-- END #main -->

<?php get_footer(); ?>
