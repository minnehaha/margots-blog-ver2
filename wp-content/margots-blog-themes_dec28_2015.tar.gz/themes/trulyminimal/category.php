<?php get_header(); ?>

<div id="main">
	<?php get_sidebar(); ?>
	
	<div id="content">
		<?php if( framework_get_template( 'category' ) ) :
		foreach( framework_get_template( 'category' ) as $section ) :

			framework_get_section( 'category', $section );

		endforeach;
		endif; ?>
	</div><!-- END #content -->

	<div class="clear"></div>
</div><!-- END #main -->

<?php get_footer(); ?>